if (True == 3):
    print(True)
else:
    print(False)

print(True+True)

x=10
while x:
    print(x,end=', ')
    x-=1
print(x)