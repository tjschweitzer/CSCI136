import sys

number = int(sys.argv[1])
i=0
while i**2<=number:
    print(i**2)
    i+=1
    